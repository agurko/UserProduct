package com.example.UserProduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
